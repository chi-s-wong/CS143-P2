Chi Wong
Omar Tleimat
P2B

For this project, we were only able to generate the datasets that we
processed with 20% of the overall data.

We did by using the sample() method as mentioned in the spec.

Outside Sources:

https://spark.apache.org/docs/2.1.0/api/python/pyspark.ml.html
https://stackoverflow.com/questions/34077353/how-to-change-dataframe-column-names-in-pyspark
https://stackoverflow.com/questions/46813283/select-columns-in-pyspark-dataframe
https://stackoverflow.com/questions/36132322/join-two-data-frames-select-all-columns-from-one-and-some-columns-from-the-othe
